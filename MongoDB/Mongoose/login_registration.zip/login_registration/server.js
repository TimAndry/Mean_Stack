//EXPRESS
var express = require('express');
var app = express();

//BODYPARSER
var bodyParser = require('body-parser');
app.use(bodyParser.urlencoded({ extended: true }));

//PATH
var path = require('path');
app.use(express.static(path.join(__dirname, './static')));
app.set('views', path.join(__dirname, './views'));
app.set('view engine', 'ejs');

//SESSION
var session = require('express-session');
app.use(session({
    secret: 'Dontlookatme',
    resave: false,
    saveUninitialized: true,
    cookie: { maxAge: 60000 }
}))

//MONGOOSE
var mongoose = require('mongoose');
mongoose.connect('mongodb://localhost/basic_mongoose');
const UserSchema = new mongoose.Schema(
    {
        fname: { type: String, required: [true, "first name must be included"], minlength: 3, maxlength: 45 },
        lname: { type: String, required: [true, "first name must be included"], minlength: 3, maxlength: 45 },
        email: { type: String, required: [true, "email must be included"], minlength: 3, maxlength: 45 },
        bdate: { type: String, required: [true, "birthday must be included"], minlength: 3, maxlength: 45 },
        password: { type: String, required: [true, "password must be included"], minlength: 6, maxlength: 90 },
    },
    { timestamps: true }
)


//more validations

var User = mongoose.model('User', UserSchema);
mongoose.Promise = global.Promise;

//FLASH
const flash = require('express-flash');
app.use(flash());

//BCRYPT
const bcrypt = require('bcryptjs');


//*************************[GOOD OLD LOGIC] ******************************//

app.get('/', function (req, res) {
    res.render('index', {})
})

app.post('/register', function (req, res) {
    if (req.body.password == req.body.password2) {
        bcrypt.hash(req.body.password, 10, function (err, hash) {
            var user = new User(req.body);
            user.password = hash;
            User.find({ email: req.body.email }, function (err, someone) {
                if (someone.length > 0) {
                    req.flash('registration', 'this email is already registered');
                    res.redirect('/');
                } else {
                    user.save(function (err) {
                        if (err) {
                            console.log("We have an error!", err);
                            for (var key in err.errors) {
                                req.flash('registration', err.errors[key].message);
                            }
                            res.redirect('/');
                        }
                        else {
                            req.session.id = user.id;
                            console.log(req.session.id);
                            res.redirect('/user/' + req.session.id);
                        }
                    });
                }
            });
        })
    }
    else {
        console.log('try again...');
        req.flash('registration', 'passwords must match');
        res.redirect('/');
    }
})

app.post('/login', function (req, res) {
    console.log(req.body.email);
    User.find({ email: req.body.email }, function (err, auser) {
        bcrypt.compare(req.body.password, auser[0].password, function (err, result) {
            if (result == true) {
                req.session.id = auser[0].id;
                console.log(req.session.id)
                res.redirect('/user/' + req.session.id);
            }
            else {
                req.flash('registration', 'this user/password combination does not match any records');
                res.redirect('/');
            }
        });
    });
});

app.get('/user/:id', function (req, res){
    res.render('user', {});
})

//*********************************[SERVER]*************************************//
app.listen(8000, function () {
    console.log("listening on port 8000");
})